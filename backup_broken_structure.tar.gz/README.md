# 🤵 Habesha Dating Bot

A modern, secure, and culturally-aware dating platform for the Habesha community, built on Telegram with enterprise-grade infrastructure.

## ✨ Features

- **🌐 Bilingual** - Full Amharic/English support, switch anytime
- **🛡️ AI Verification** - Automatic photo authenticity checking
- **📸 Smart Compression** - 95% storage reduction with quality preservation
- **👥 Admin Dashboard** - Comprehensive management tools
- **💰 Payment System** - TeleBirr, CBE, Bank transfer support
- **🤝 Referral Program** - Viral growth with rewards
- **📊 Analytics** - Real-time insights and reporting
- **🔒 Enterprise Security** - Supabase, Redis, encrypted storage

## 🚀 Quick Start

### 1. Clone and Setup
```bash
git clone https://github.com/yourusername/habesha-dating-bot.git
cd habesha-dating-bot
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt